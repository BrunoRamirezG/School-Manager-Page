<?php   
    include('funciones_alumnos.php'); 
    cerrar_sesion_admin();
?>