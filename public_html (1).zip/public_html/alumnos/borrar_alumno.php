<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" || $_SERVER["REQUEST_METHOD"] == "GET") {
        $id_alumno = $_REQUEST["id_alumno"];
    }
    include('funciones_alumno.php');
    cargar_base();
    $conn=cargar_base();
    $sql = "DELETE FROM alumnos WHERE id_alumno = $id_alumno";
    $result = mysqli_query($conn, $sql);
    header("Location: index.php"); 
?>