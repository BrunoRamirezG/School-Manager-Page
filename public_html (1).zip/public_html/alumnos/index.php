<?php     
    include('funciones_alumno.php'); 
    $id_alumno_actual=verificar_existe_sesion_alumno();
    include('../recursos/encabezado.php');
?>
<div id="contenido">
    <h1>Zona de Alumnos</h1>
    <table id="tabla_alumno">
    <thead>
        <tr><th>#</th><th>usuario</th><th>clave</th></tr>
    </thead>
    <tbody>
        <?php  listado_alumnos(); ?>    
    </tbody>
    </table>
    <br>
    <form method='post' action='formulario_agregar_alumno.php'>        
    <button type='submit'>Agregar</button></form>
    <form method='post' action='cerrar_sesion_alumno.php'>        
    <button type='submit'>Cerrar Sesión</button></form>
</div>
<?php  include('../recursos/pie_pagina.php'); ?>