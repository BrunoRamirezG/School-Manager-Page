<?php   include('../recursos/encabezado.php');  ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" || $_SERVER["REQUEST_METHOD"] == "GET") {
    $id_admin = $_REQUEST["id_alumno"];
}
include('funciones_alumnos.php');
$resultados = get_admin($id_alumno);
$usuario = $resultados[0];
$clave = $resultados[1];

?>
<div id="contenido" >
    <div id="login">
        <div id="formularioValidacion">
            <h2>modificar alumno</h2>
            <form action="modificar_alumno.php" method="get">
                <div class="form-group">
                    <label for="usuario">Usuario:</label>
                    <input type="text" id="usuario" name="usuario" value="<?php echo $usuario ?>" required>
                </div>
                <div class="form-group">
                    <label for="clave">clave:</label>
                    <input type="clave" id="clave" name="clave" value="<?php echo $clave ?>" maxlength="8" required>
                </div>
                <input type="hidden" id="id_admin" name="id_admin" value="<?php echo $id_admin ?>" >
                <button type="submit">Salvar</button>
            </form>
        </div>
    </div>
</div>

<?php  include('../recursos/pie_pagina.php'); ?>

<!-- http://localhost/administradores/formulario_modificar_admin.php?id_admin=1  -->