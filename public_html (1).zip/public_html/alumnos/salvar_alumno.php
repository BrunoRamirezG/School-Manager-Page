<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" || $_SERVER["REQUEST_METHOD"] == "GET") {
    // Capturar las variables enviadas por POST o GET
    $nombre = $_REQUEST["nombre"];
    $usuario = $_REQUEST["usuario"];
    $clave = $_REQUEST["clave"];

}

include('funciones_alumno.php');
cargar_base();
$conn=cargar_base();

$sql="INSERT INTO administradores (nombre,usuario,clave) values (´'$nombre',$usuario','$clave');";
$result = mysqli_query($conn, $sql);
header("Location: index.php"); 
    
?>