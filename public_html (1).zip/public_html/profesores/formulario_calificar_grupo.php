<?php   include('../recursos/encabezado.php');  ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" || $_SERVER["REQUEST_METHOD"] == "GET") {
    $id_grupo = $_REQUEST["id_grupo"];
}
include('funciones_profesores.php');
?>
<div id="contenido" >
    <table>
        <tr>
            <th>Alumno</th>
            <th>Calificaion</th>
            <th>AAsistencia</th>
        </tr>
        <tr>
            <tbody>
                <?php
                    listado_grupos_profesor($id_grupo);
                ?>
            </tbody>
        </tr>
    </table>
</div>

<?php  include('../recursos/pie_pagina.php'); ?>
