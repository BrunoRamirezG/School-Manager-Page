<?php     
    include('funciones_profesores.php'); 
    $id_profesor_actual=verificar_existe_sesion_profesor();
    include('../recursos/encabezado.php');
?>
<div id="contenido">
    <h1>Bienvenido profesor</h1>
    <table id="tabla_grupos">
    <thead>
        <tr><th>#</th><th>usuario</th><th>clave</th></tr>
    </thead>
    <tbody>
        <?php  listado_grupos($id_profesor_actual); ?>    
    </tbody>
    </table>
    <br>
    <form method='post' action='cerrar_sesion_profesores.php'>        
    <button type='submit'>Cerrar Sesión</button></form>
</div>
<?php  include('../recursos/pie_pagina.php'); ?>
