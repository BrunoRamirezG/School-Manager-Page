<?php   
    include('funciones_profesores.php'); 
    cerrar_sesion_profesor();
?>