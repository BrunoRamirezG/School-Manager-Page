<?php   
    include('funciones_administradores.php'); 
    cerrar_sesion_admin();
?>