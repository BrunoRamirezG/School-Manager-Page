<?php     
    include('funciones_administradores.php'); 
    $id_admin_actual=verificar_existe_sesion_admin();
    include('../recursos/encabezado.php');
?>
<div id="contenido">
    <h1>Zona de administradores</h1>
    <table id="tabla_administradores">
    <thead>
        <tr><th>#</th><th>usuario</th><th>clave</th></tr>
    </thead>
    <tbody>
        <?php  listado_administradores(); ?>    
    </tbody>
    </table>
    <br>
    <form method='post' action='formulario_agregar_admin.php'>        
    <button type='submit'>Agregar</button></form>
    <form method='post' action='cerrar_sesion_admin.php'>        
    <button type='submit'>Cerrar Sesión</button></form>
</div>
<?php  include('../recursos/pie_pagina.php'); ?>
