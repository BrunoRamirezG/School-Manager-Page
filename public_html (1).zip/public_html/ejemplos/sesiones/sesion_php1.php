<?php
    // Iniciar la sesión
    session_start();
    $_SESSION['id_admin'] = 1;
    $_SESSION['id_tipo_usuario'] = 3;
    $_SESSION['logueado'] = true;
    header('Location: sesion_php2.php');
    exit;

?>
