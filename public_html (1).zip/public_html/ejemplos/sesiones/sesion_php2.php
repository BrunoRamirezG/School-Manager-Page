<?php
// Iniciar la sesión
session_start();

// Verificar si el usuario está logueado
if (isset($_SESSION['logueado']) && $_SESSION['logueado'] === true) {
    // El usuario está logueado, puedes acceder a sus datos
    $id_admin = $_SESSION['id_admin'];
    $id_tipo_alumno = $_SESSION['id_tipo_usuario'];
    echo 'Bienvenido, ' . $id_admin;
    echo '<br>tipo, ' . $id_tipo_alumno;
} else {
    // El usuario no está logueado, redirigir a la página de inicio de sesión
    header('Location: index.php');
    exit;
}
?>
